﻿namespace Vfs.Security
{
  /// <summary>
  /// Provides business logic to resolve file and folder
  /// permissions for a requesting party.
  /// </summary>
  public interface IFileSystemSecurity
  {
    /// <summary>
    /// Gets authorization claims for a given folder resource.
    /// </summary>
    /// <param name="folder">The currently processed folder.</param>
    /// <returns>The requesting party's permissions for the
    /// submitted <paramref name="folder"/>.</returns>
    FolderClaims GetFolderClaims(VirtualFolderInfo folder);

    /// <summary>
    /// Gets authorization claims for a given file resource.
    /// </summary>
    /// <param name="file">The currently processed file.</param>
    /// <returns>The requesting party's permissions for the
    /// submitted <paramref name="file"/>.</returns>
    FileClaims GetFileClaims(VirtualFileInfo file);
  }

}