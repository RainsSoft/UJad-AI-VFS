﻿using System;
using System.IO;


namespace Vfs.Security
{
  public class WindowsIdentityClaimsProvider : IFileSystemSecurity
  {
    /// <summary>
    /// The folder that is used as a base in order to process
    /// relative file paths.
    /// </summary>
    public DirectoryInfo RootDirectory { get; set; }



    /// <summary>
    /// Gets authorization claims for a given folder resource.
    /// </summary>
    /// <param name="folder">The currently processed folder.</param>
    /// <returns>The requesting party's permissions for the
    /// submitted <paramref name="folder"/>.</returns>
    public FolderClaims GetFolderClaims(VirtualFolderInfo folder)
    {
      throw new NotImplementedException(""); //TODO provide implementation
    }


    /// <summary>
    /// Gets authorization claims for a given file resource.
    /// </summary>
    /// <param name="file">The currently processed file.</param>
    /// <returns>The requesting party's permissions for the
    /// submitted <paramref name="file"/>.</returns>
    public FileClaims GetFileClaims(VirtualFileInfo file)
    {
      throw new NotImplementedException();
    }
  }
}
