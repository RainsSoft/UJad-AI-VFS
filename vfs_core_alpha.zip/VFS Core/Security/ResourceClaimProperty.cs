using System.Runtime.Serialization;

namespace Vfs.Security
{
  /// <summary>
  /// A named binary flag that depicts a custom
  /// property associated with a resource's
  /// permissions.
  /// </summary>
  [DataContract]
  public class ResourceClaimProperty
  {
    /// <summary>
    /// The property name.
    /// </summary>
    [DataMember(Order = 0)]
    public string Name { get; set; }

    /// <summary>
    /// The boolean property value, which indicates
    /// whether the claim is granted or not.
    /// </summary>
    [DataMember(Order = 1)]
    public bool Value { get; set; }
  }
}