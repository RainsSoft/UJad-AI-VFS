﻿using System.Security.Principal;

namespace Vfs.Security
{
  /// <summary>
  /// A security plug-in that authorizes all requests.
  /// </summary>
  public class NullSecurity : IFileSystemSecurity
  {
    public FolderClaims GetFolderClaims(VirtualFolderInfo folder)
    {
      return FolderClaims.CreatePermissive();
    }

    public FileClaims GetFileClaims(VirtualFileInfo file)
    {
      return FileClaims.CreatePermissive();
    }
  }
}
