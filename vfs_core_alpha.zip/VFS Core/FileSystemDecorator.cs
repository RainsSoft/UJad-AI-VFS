﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Vfs
{
  /// <summary>
  /// Provides a base class to extend a given <see cref="IFileSystemProvider"/>
  /// implementation in order to process or intercept FS-related
  /// calls.
  /// </summary>
  public abstract class FileSystemDecorator //: IFileSystemProvider
  {
    /// <summary>
    /// The decorated file system.
    /// </summary>
    protected IFileSystemProvider DecoratedFileSystem { get; private set; }


    /// <summary>
    /// Initializes the class with the <see cref="IFileSystemProvider"/>
    /// to be decorated.
    /// </summary>
    /// <param name="decorated">The decorated file system.</param>
    /// <exception cref="ArgumentNullException">If <paramref name="decorated"/>
    /// is a null reference.</exception>
    protected FileSystemDecorator(IFileSystemProvider decorated)
    {
      if (decorated == null) throw new ArgumentNullException("decorated");
      DecoratedFileSystem = decorated;
    }
  }
}