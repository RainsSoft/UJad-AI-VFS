﻿using System;
using System.Runtime.Serialization;


namespace Vfs
{
#if !SILVERLIGHT
  [Serializable]
#endif
  public class VirtualResourceNotFoundException : VfsException
  {
    /// <summary>
    /// The resource in question, if any.
    /// </summary>
    public VirtualResourceInfo Resource { get; set; }

    public VirtualResourceNotFoundException()
    {
    }

    public VirtualResourceNotFoundException(string message) : base(message)
    {
    }

    public VirtualResourceNotFoundException(string message, Exception inner) : base(message, inner)
    {
    }

#if !SILVERLIGHT
    protected VirtualResourceNotFoundException(
        SerializationInfo info,
        StreamingContext context) : base(info, context)
    {
    }
#endif
  }
}
