﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Vfs.Exceptions
{
  /// <summary>
  /// Helper class that assists in creating verbose
  /// exceptions for common FS and VFS related
  /// error conditions.
  /// </summary>
  public static class ExceptionBuilder
  {

  }
}
