﻿using System;
using System.Diagnostics;
using System.IO;
using System.Threading;
using Microsoft.Win32;

namespace Vfs.Util
{
  /// <summary>
  /// Provides helper methods that simplify dealing with file
  /// contents and content data access.
  /// </summary>
  public static class ContentUtil
  {
    //set the default content-type
    private const string DefaultContentType = "application/unknown";

    /// <summary>
    /// Resolves the content type for a given file based on the file's
    /// extension.
    /// </summary>
    /// <param name="fileExtension">File extension including the dot (.), e.g.
    /// <c>.zip</c> or <c>.txt</c>.</param>
    /// <returns>The resolved content type, or a default of <c>application/unknown</c>
    /// if the type couldn't be resolved.</returns>
    public static string ResolveContentType(string fileExtension)
    {
#if !SILVERLIGHT
      try
      {
        //look for fileExtension
        RegistryKey extensionKey = Registry.ClassesRoot.OpenSubKey(fileExtension);
        if (extensionKey == null) return DefaultContentType;

        //retrieve Content Type value
        const string contentType = "Content Type";
        return extensionKey.GetValue(contentType, DefaultContentType).ToString();
      }
      catch
      {
        return DefaultContentType;
      }
#endif

      return DefaultContentType;
    }


    /// <summary>
    /// This is a convenience extension method for <see cref="IFileSystemProvider"/> instances,
    /// which retrieves the binary contents from a provivder, and writes them into a given file.
    /// </summary>
    /// <param name="provider">The <see cref="IFileSystemProvider"/> to be invoked in order to get access to the
    /// file's contents.</param>
    /// <param name="fileInfo">Provides meta information about the file to be read.</param>
    /// <param name="filePath">The file to be created. If a corresponding file already
    /// exists, it will be overwritten.</param>
    /// <exception cref="ArgumentNullException">If <paramref name="fileInfo"/>
    /// is a null reference.</exception>
    /// <exception cref="ArgumentNullException">If <paramref name="filePath"/>
    /// is a null reference.</exception>
    public static void SaveFile(this IFileSystemProvider provider, VirtualFileInfo fileInfo, string filePath)
    {
      using (Stream destination = new FileStream(filePath, FileMode.Create, FileAccess.Write))
      {
        ReadFile(provider, fileInfo, destination, true);
      }
    }

    /// <summary>
    /// This is a convenience extension method for <see cref="IFileSystemProvider"/> instances,
    /// which retrieves the binary contents from a provivder, and writes them into a given file.
    /// This is a non-blocking operation which invokes the submitted <param name="completionCallback" />
    /// once the process has been completed.
    /// </summary>
    /// <param name="provider">The <see cref="IFileSystemProvider"/> to be invoked in order to get access to the
    /// file's contents.</param>
    /// <param name="fileInfo">Provides meta information about the file to be read.</param>
    /// <param name="filePath">The file to be created. If a corresponding file already
    /// exists, it will be overwritten.</param>
    /// <param name="completionCallback">Invoked as soon as the operation has been completed,
    /// or aborted. This is an optional parameter, which can be null.</param>
    /// <exception cref="ArgumentNullException">If <paramref name="fileInfo"/>
    /// is a null reference.</exception>
    /// <exception cref="ArgumentNullException">If <paramref name="filePath"/>
    /// is a null reference.</exception>
    public static void BeginSaveFile(this IFileSystemProvider provider, VirtualFileInfo fileInfo, string filePath,
                                     Action<FileOperationResult> completionCallback)
    {
      Stream destination = new FileStream(filePath, FileMode.Create, FileAccess.Write);
      BeginReadFile(provider, fileInfo, destination, completionCallback);
    }


    /// <summary>
    /// This is a convenience extension method for <see cref="IFileSystemProvider"/> instances,
    /// which gets the binary contents as a stream as a blocking operation.
    /// Use the methods in <see cref="ContentUtil"/> class for simplified stream
    /// handling.
    /// </summary>
    /// <param name="provider">The <see cref="IFileSystemProvider"/> to be invoked in order to get access to the
    /// file's contents.</param>
    /// <param name="fileInfo">Provides meta information about the file to be read.</param>
    /// <param name="destination">A stream to which the file's contents are written.</param>
    /// <param name="autoCloseStream">Whether to automatically close the submitted
    /// <paramref name="destination"/> stream.</param>
    /// <exception cref="ArgumentNullException">If <paramref name="fileInfo"/>
    /// is a null reference.</exception>
    /// <exception cref="ArgumentNullException">If <paramref name="destination"/>
    /// is a null reference.</exception>
    public static void ReadFile(this IFileSystemProvider provider, VirtualFileInfo fileInfo, Stream destination, bool autoCloseStream)
    {
      if (provider == null) throw new ArgumentNullException("provider");
      if (fileInfo == null) throw new ArgumentNullException("fileInfo");
      if (destination == null) throw new ArgumentNullException("destination");

      try
      {
        using (Stream stream = provider.ReadFileContents(fileInfo.FullName))
        {
          stream.WriteTo(destination);
        }
      }
      finally
      {
        if(autoCloseStream)
        {
          destination.Close();
        }
      }
    }


    /// <summary>
    /// This is a convenience extension method for <see cref="IFileSystemProvider"/> instances,
    /// which writes the data of a given file to the submitted output stream as a non-blocking
    /// operation, and invokes the submitted delegate once the process has been completed.
    /// </summary>
    /// <param name="provider">The <see cref="IFileSystemProvider"/> to be invoked in order to get access to the
    /// file's contents.</param>
    /// <param name="fileInfo">Provides meta information about the file to be read.</param>
    /// <param name="output">A stream to which the file's contents are written. The stream will
    /// be automatically closed as soon as the operations finishes.</param>
    /// <param name="completionCallback">Invoked as soon as the operation has been completed,
    /// or aborted. This is an optional parameter, which can be null.</param>
    /// <exception cref="ArgumentNullException">If <paramref name="fileInfo"/>
    /// is a null reference.</exception>
    /// <exception cref="ArgumentNullException">If <paramref name="output"/>
    /// is a null reference.</exception>
    public static void BeginReadFile(this IFileSystemProvider provider, VirtualFileInfo fileInfo, Stream output,
                                     Action<FileOperationResult> completionCallback)
    {
      ThreadPool.QueueUserWorkItem(delegate
                                     {
                                       FileOperationResult result = new FileOperationResult(fileInfo);
                                       try
                                       {
                                         ReadFile(provider, fileInfo, output, true);
                                         if (completionCallback != null) completionCallback(result);
                                       }
                                       catch (Exception e)
                                       {
                                         if (completionCallback != null)
                                         {
                                           result.Exception = e;
                                           completionCallback(result);
                                         }
                                         else
                                         {
                                           //log an error in order to make sure this doesn't go unnoticed
                                           string msg = "Async file read operation failed silently for file '{0}':\n{1}";
                                           msg = String.Format(msg, fileInfo.FullName, e);
                                           Debug.WriteLine(msg);
                                         }
                                       }
                                     });
    }


    /// <summary>
    /// Reads a given <paramref name="source"/> stream and writes its contents
    /// to the submitted <paramref name="destination"/> stream, using a default
    /// buffer size of <c>32768</c> bytes.
    /// </summary>
    /// <param name="source">The stream to source data from.</param>
    /// <param name="destination">The stream to write data to.</param>
    public static void WriteTo(this Stream source, Stream destination)
    {
      source.WriteTo(destination, 32768);
    }


    /// <summary>
    /// Reads a given <paramref name="source"/> stream and writes its contents
    /// to a given file.
    /// </summary>
    /// <param name="source">The stream to source data from.</param>
    /// <param name="filePath">The file to be created. If a corresponding file already
    /// exists, it will be overwritten.</param>
    /// <exception cref="ArgumentNullException">If <paramref name="source"/>
    /// is a null reference.</exception>
    /// <exception cref="ArgumentNullException">If <paramref name="filePath"/>
    /// is a null reference.</exception>
    public static void WriteTo(this Stream source, string filePath)
    {
      if (source == null) throw new ArgumentNullException("source");
      if (filePath == null) throw new ArgumentNullException("filePath");

      using (Stream destination = new FileStream(filePath, FileMode.Create, FileAccess.Write))
      {
        source.WriteTo(destination);
      }
    }



    /// <summary>
    /// Reads a given <paramref name="source"/> stream and writes its contents
    /// to the submitted <paramref name="destination"/> stream.
    /// </summary>
    /// <param name="source">The stream to source data from.</param>
    /// <param name="destination">The stream to write data to.</param>
    /// <param name="bufferSize">The buffer size to be used to read the
    /// <paramref name="source"/> stream.
    /// </param>
    public static void WriteTo(this Stream source, Stream destination, int bufferSize)
    {
      if (source == null) throw new ArgumentNullException("source");
      if (destination == null) throw new ArgumentNullException("destination");

      //use default byte sizes
      byte[] buffer = new byte[bufferSize];

      while (true)
      {
        int bytesRead = source.Read(buffer, 0, buffer.Length);
        if (bytesRead > 0)
        {
          destination.Write(buffer, 0, bytesRead);
        }
        else
        {
          destination.Flush();
          break;
        }
      }
    }
  }
}