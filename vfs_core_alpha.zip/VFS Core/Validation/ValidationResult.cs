﻿using System;
using Vfs.Auditing;

namespace Vfs.Validation
{
  /// <summary>
  /// Encapsulates information about a given validation task.
  /// Validation results are used in order to delegate validation
  /// and audit / escalate the results.
  /// </summary>
  [Obsolete("not used anymore", true)]
  public class ValidationResult
  {
    /// <summary>
    /// Whether validation succeeded or not.
    /// </summary>
    public bool IsValid { get; set; }

    /// <summary>
    /// An optional audit message, which may encapsulate detailed
    /// information about what happened.
    /// </summary>
    public AuditItem Audit { get; set; }

    /// <summary>
    /// Assigns a given exception which is supposed to be thrown
    /// eventually.
    /// </summary>
    public Exception Exception { get; set; }


    /// <summary>
    /// Initializes a new validation result, which by default returns
    /// true fo rthe <see cref="IsValid"/> property.
    /// </summary>
    public ValidationResult() : this(true)
    {
    }

    /// <summary>
    /// Initializes a new instance of the <see cref="T:System.Object"/> class.
    /// </summary>
    /// <param name="isValid">Whether the validation succeeded or not.</param>
    public ValidationResult(bool isValid)
    {
      IsValid = isValid;
    }

    /// <summary>
    /// Initializes a new instance of the <see cref="T:System.Object"/> class.
    /// </summary>
    /// <param name="isValid">Whether the validation succeeded or not.</param>
    /// <param name="audit">Complementary information.</param>
    public ValidationResult(bool isValid, AuditItem audit)
    {
      IsValid = isValid;
      Audit = audit;
    }
  }
}
