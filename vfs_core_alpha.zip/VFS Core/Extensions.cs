﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using Vfs.Util;

namespace Vfs
{
  public static class Extensions
  {
    /// <summary>
    /// Performs a given action on every item of a given sequence.
    /// </summary>
    /// <typeparam name="T">The collection's content.</typeparam>
    /// <param name="source">The sequence to be processed.</param>
    /// <param name="action">An action delegate that is being invoked
    /// for every item of the <paramref name="source"/> sequence.</param>
    /// <exception cref="ArgumentNullException">If <paramref name="action"/>
    /// is a null reference.</exception>
    public static void Do<T>(this IEnumerable<T> source, Action<T> action)
    {
      if (action == null) throw new ArgumentNullException("action");

      foreach (var item in source)
      {
        action(item);
      }
    }


    /// <summary>
    /// Filters a collection of file system resources by applying a given
    /// regular expression to the resource's <see cref="VirtualResourceInfo.Name"/>.
    /// </summary>
    /// <typeparam name="T">The resource type.</typeparam>
    /// <param name="resources">The unfiltered collection.</param>
    /// <param name="searchPattern">A regex pattern to be applied.</param>
    /// <returns>A filtered collection.</returns>
    public static IEnumerable<T> Filter<T>(this IEnumerable<T> resources, string searchPattern) where T:VirtualResourceInfo
    {
      //convert wildcard syntax to regex
      string escapedPattern = Regex.Escape(searchPattern);
      escapedPattern = escapedPattern.Replace("\\*", ".*");
      escapedPattern = escapedPattern.Replace("\\?", ".");
      escapedPattern = "^" + escapedPattern + "$";

      Regex regex = new Regex(escapedPattern);
      return resources.Where(resource => regex.IsMatch(resource.Name));
    }


    #region create resource infos for local files / directories

    /// <summary>
    /// Creates meta information for a given file.
    /// </summary>
    /// <param name="localDirectory">The local directory.</param>
    /// <returns>A <see cref="VirtualFolderInfo"/> that matches the submitted directory.</returns>
    /// <exception cref="ArgumentNullException">If <paramref name="localDirectory"/>
    /// is a null reference.</exception>
    public static VirtualFolderInfo CreateFolderResourceInfo(this DirectoryInfo localDirectory)
    {
      Ensure.ArgumentNotNull(localDirectory, "localDirectory");

      localDirectory.Refresh();
      var item = new VirtualFolderInfo();
      MapProperties(localDirectory, item);
      item.ParentFolderPath = localDirectory.Parent == null ? String.Empty : localDirectory.Parent.FullName;
      item.IsEmpty = localDirectory.IsEmpty();

      return item;
    }


    /// <summary>
    /// Checks whether a given directory is empty or not. Returns false
    /// if the directory does not exist.
    /// </summary>
    /// <param name="directory">The directory to check.</param>
    /// <returns></returns>
    internal static bool IsEmpty(this DirectoryInfo directory)
    {
      try
      {
        string fullName = directory.FullName;
        if (!directory.Exists) return false;
#if !SILVERLIGHT
        return Directory.GetFiles(fullName).Length == 0 &&
               Directory.GetDirectories(fullName).Length == 0;
#endif

#if SILVERLIGHT
        return Directory.EnumerateFileSystemEntries(fullName).FirstOrDefault() != null;
#endif

      }
      catch (DirectoryNotFoundException)
      {
        //apparently, the folder was just removed
        return false;
      }
    }


    /// <summary>
    /// Creates meta information for a given file.
    /// </summary>
    /// <param name="localFile">The local file.</param>
    /// <returns>A <see cref="VirtualFileInfo"/> that matches the submitted file.</returns>
    /// <exception cref="ArgumentNullException">If <paramref name="localFile"/>
    /// is a null reference.</exception>
    public static VirtualFileInfo CreateFileResourceInfo(this FileInfo localFile)
    {
      if (localFile == null) throw new ArgumentNullException("localFile");
      localFile.Refresh();
      var item = new VirtualFileInfo
                   {
                     Length = localFile.Exists ? localFile.Length : 0,
                     ContentType = ContentUtil.ResolveContentType(localFile.Extension),
                     ParentFolderPath = localFile.DirectoryName,
                   };

      MapProperties(localFile, item);
      return item;
    }


    /// <summary>
    /// Maps common properties for files and folders.
    /// </summary>
    private static void MapProperties(FileSystemInfo localItem, VirtualResourceInfo virtualItem)
    {
      virtualItem.Name = localItem.Name;
      virtualItem.FullName = localItem.FullName;
      virtualItem.Description = String.Empty;

      bool exists = localItem.Exists;
      virtualItem.CreationTime = exists ? localItem.CreationTime : (DateTimeOffset?)null;
      virtualItem.LastWriteTime = exists ? localItem.LastWriteTime : (DateTimeOffset?)null;
      virtualItem.LastAccessTime = exists ? localItem.LastAccessTime : (DateTimeOffset?)null;

      if(exists)
      {
        var attributes = localItem.Attributes;
        virtualItem.IsHidden = ((attributes & FileAttributes.Hidden) == FileAttributes.Hidden);
        virtualItem.IsReadOnly = ((attributes & FileAttributes.ReadOnly) == FileAttributes.ReadOnly);
      }
      else
      {
        virtualItem.IsHidden = false;
        virtualItem.IsReadOnly = false;
      }
    }

    #endregion

  }
}
