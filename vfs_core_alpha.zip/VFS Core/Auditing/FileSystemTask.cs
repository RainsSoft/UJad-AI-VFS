using System;

namespace Vfs.Auditing
{
  /// <summary>
  /// Flags that define the context of an operation
  /// on the file system.
  /// </summary>
  [Flags]
  public enum FileSystemTask
  {
    Undefined,
    Unknown,
    All,

    FileInfoRequest,
    FolderInfoRequest,
    RootFolderInfoRequest,

    FolderContentsRequest,
    ChildFilesRequest,
    ChildFoldersRequest,
    
    FileDownloadRequest,
    FileUploadRequest,

    FileMoveRequest,
    FileCopyRequest,
    FileDeleteRequest,
    FolderMoveRequest,
    FolderCopyRequest,
    FolderDeleteRequest,
    FolderCreateRequest,

    FileParentRequest,
    FolderParentRequest,

    CheckFileAvailability,
    CheckFolderAvailability,

    CreateFolderPathRequest,
    CreateFilePathRequest
  }
}