﻿using System;
using System.IO;

namespace Vfs.LocalFileSystem
{
  public class FolderItem : VirtualFolderItem
  {
    public DirectoryInfo LocalDirectory { get; set; }

    /// <summary>
    /// The <see cref="QualifiedIdentifier"/> that is returned
    /// if this class represents the file system root.
    /// </summary>
    public const string RootIdentifier = "{ROOT}";

    public FolderItem()
    {
    }

    public FolderItem(DirectoryInfo localDirectory, VirtualFolderInfo virtualFolder)
    {
      LocalDirectory = localDirectory;
      ResourceInfo = virtualFolder;
    }

    /// <summary>
    /// Indicates whether the resource physically exists on the file system
    /// or not.
    /// </summary>
    public override bool Exists
    {
      get { return ResourceInfo.IsRootFolder || LocalDirectory != null && LocalDirectory.Exists; }
    }

    /// <summary>
    /// Gets a string that provides the fully qualified string of the resource that
    /// should be used for internal auditing (as opposite to the
    /// <see cref="VirtualResourceInfo.FullName"/>, which is publicly exposed to
    /// clients, e.g. in exception messages).
    /// </summary>
    public override string QualifiedIdentifier
    {
      get
      {
        if (ResourceInfo.IsRootFolder) return RootIdentifier;
        return LocalDirectory == null ? String.Empty : LocalDirectory.FullName;
      }
    }
  }
}
