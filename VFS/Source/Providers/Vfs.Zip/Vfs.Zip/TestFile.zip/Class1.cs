﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ICSharpCode.SharpZipLib.Zip;

namespace Vfs.Zip
{
  public class Class1
  {
    void XXX()
    {
      ZipFile file = new ZipFile(@"D:\Repositories\Open Source\VFS\Source\Providers\Vfs.Zip\Vfs.Zip\TestFile2.zip");
      Console.Out.WriteLine("file.Name = {0}", file.Name);
      for (int i = 0; i < file.Count; i++)
      {
        ZipEntry entry = file[i];
        Console.Out.WriteLine("file[i].Name = {0}", entry.Name);
//        Console.Out.WriteLine("file[i].Index = {0}", entry.ZipFileIndex);
      }

      file.BeginUpdate();
      file.AddDirectory("Folder0/Test/");

      int folderIndex = file.FindEntry("Folder0/Download/", true);
      file[folderIndex].
      Console.Out.WriteLine("folderIndex = {0}", folderIndex);
      
      file.Delete(file[folderIndex]);
      file.CommitUpdate();

      for (int i = 0; i < file.Count; i++)
      {
        ZipEntry entry = file[i];
        Console.Out.WriteLine("file[i].Name = {0}", entry.Name);
        Console.Out.WriteLine("file[i].Index = {0}", entry.ZipFileIndex);
      }
    }
  }
}
