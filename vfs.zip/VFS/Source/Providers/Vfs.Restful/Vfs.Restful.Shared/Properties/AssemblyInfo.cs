﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Vfs.Restful.Shared")]
[assembly: AssemblyDescription("")]

[assembly: ComVisible(false)]
[assembly: Guid("fceba292-2684-4f00-ac64-faead742fa68")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
