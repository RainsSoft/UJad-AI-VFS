﻿using System.IO;
using Hardcodet.Commons.IO;

namespace Vfs.LocalFileSystem.Test
{
  public static class InternalTestUtil
  {
  }
}
