﻿using System.Reflection;
using System.Runtime.InteropServices;


[assembly: AssemblyTitle("VFS - Local FS Provider")]
[assembly: AssemblyDescription("A VFS provider that manages access to the local file system.")]

[assembly: AssemblyVersion("0.2.0.0")]
[assembly: AssemblyFileVersion("0.2.0.0")]



[assembly: ComVisible(false)]
[assembly: Guid("2c6c8936-93f9-4a3c-b2ed-c8a70d6f7020")]
