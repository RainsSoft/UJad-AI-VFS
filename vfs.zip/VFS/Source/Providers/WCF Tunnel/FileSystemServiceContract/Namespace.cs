﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Vfs.FileSystemService
{
  public static class Namespace
  {
    /// <summary>
    /// The main namespace of the services.
    /// </summary>
    public const string Main = "http://vfs.hardcodet.net/ws/";
  }
}
