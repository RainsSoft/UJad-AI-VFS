﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using Vfs;

namespace Vfs.Samples.LocalClient.ViewModel
{
  /// <summary>
  /// A view model that represents the currently used file system.
  /// </summary>
  public class FileSystemViewModel : ViewModelBase
  {


  }
}
