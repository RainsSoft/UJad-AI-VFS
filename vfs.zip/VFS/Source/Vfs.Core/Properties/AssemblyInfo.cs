﻿using System.Reflection;
using System.Runtime.InteropServices;


[assembly: AssemblyTitle("VFS Core")]
[assembly: AssemblyDescription("Virtual File System (VFS) - Core Library")]

[assembly: AssemblyVersion("0.2.0.0")]
[assembly: AssemblyFileVersion("0.2.0.0")]


[assembly: ComVisible(false)]
[assembly: Guid("e2792772-6dbf-4866-ab91-f895159cb18f")]
