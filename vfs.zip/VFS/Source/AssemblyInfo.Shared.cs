using System;
using System.Reflection;

[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("hardcodet.net")]
[assembly: AssemblyProduct("Virtual File System (VFS)")]
[assembly: AssemblyCopyright("Copyright � Philipp Sumi 2010")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly:CLSCompliant(true)]